# Deployment Guide

This guide provides step-by-step instructions for deploying the ATS Integration Service to AWS Lambda.

## Prerequisites

1. **AWS Account** with appropriate permissions
2. **AWS CLI** configured with credentials
3. **Node.js and npm** installed
4. **Python 3.11** installed
5. **Serverless Framework** installed globally

## Pre-Deployment Checklist

- [ ] AWS credentials configured
- [ ] SuccessFactors API credentials obtained
- [ ] Dependencies installed (`npm install` and `pip install -r requirements.txt`)
- [ ] Environment variables configured
- [ ] Code tested locally

## Step 1: Configure AWS Credentials

### Option A: AWS CLI Configuration

```bash
aws configure
```

Provide:
- AWS Access Key ID
- AWS Secret Access Key
- Default region (e.g., us-east-1)
- Output format (json)

### Option B: Environment Variables

```bash
export AWS_ACCESS_KEY_ID=your-access-key
export AWS_SECRET_ACCESS_KEY=your-secret-key
export AWS_DEFAULT_REGION=us-east-1
```

### Option C: AWS Profile

```bash
export AWS_PROFILE=your-profile-name
```

## Step 2: Store Secrets in AWS Systems Manager

For production deployments, store sensitive credentials in AWS Systems Manager Parameter Store:

```bash
# Store SuccessFactors credentials
aws ssm put-parameter \
    --name "/ats-service/sf-api-url" \
    --value "https://apisalesdemo8.successfactors.com" \
    --type "String"

aws ssm put-parameter \
    --name "/ats-service/sf-company-id" \
    --value "SFPART000000" \
    --type "String"

aws ssm put-parameter \
    --name "/ats-service/sf-username" \
    --value "your-username" \
    --type "SecureString"

aws ssm put-parameter \
    --name "/ats-service/sf-password" \
    --value "your-password" \
    --type "SecureString"

aws ssm put-parameter \
    --name "/ats-service/sf-api-key" \
    --value "your-api-key" \
    --type "SecureString"
```

## Step 3: Update serverless.yml for Production

Update the `provider.environment` section in `serverless.yml`:

```yaml
provider:
  name: aws
  runtime: python3.11
  region: us-east-1
  stage: ${opt:stage, 'dev'}
  environment:
    SF_API_URL: ${ssm:/ats-service/sf-api-url}
    SF_COMPANY_ID: ${ssm:/ats-service/sf-company-id}
    SF_USERNAME: ${ssm:/ats-service/sf-username~true}
    SF_PASSWORD: ${ssm:/ats-service/sf-password~true}
    SF_API_KEY: ${ssm:/ats-service/sf-api-key~true}
```

Note: The `~true` suffix decrypts SecureString parameters.

## Step 4: Deploy to Development

```bash
# Deploy to dev stage
serverless deploy --stage dev

# Or with verbose output
serverless deploy --stage dev --verbose
```

Expected output:
```
Deploying ats-integration-service to stage dev (us-east-1)

✔ Service deployed to stack ats-integration-service-dev (112s)

endpoints:
  GET - https://abc123xyz.execute-api.us-east-1.amazonaws.com/dev/jobs
  POST - https://abc123xyz.execute-api.us-east-1.amazonaws.com/dev/candidates
  GET - https://abc123xyz.execute-api.us-east-1.amazonaws.com/dev/applications
functions:
  getJobs: ats-integration-service-dev-getJobs (5.2 MB)
  postCandidate: ats-integration-service-dev-postCandidate (5.2 MB)
  getApplications: ats-integration-service-dev-getApplications (5.2 MB)
```

## Step 5: Test Deployed API

Save the API endpoint URLs from the deployment output, then test:

```bash
# Set the deployed URL
export API_URL="https://abc123xyz.execute-api.us-east-1.amazonaws.com/dev"

# Test GET /jobs
curl -X GET "$API_URL/jobs"

# Test GET /applications
curl -X GET "$API_URL/applications"

# Test POST /candidates
curl -X POST "$API_URL/candidates" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "phone": "+1-555-0100",
    "resume_url": "https://example.com/resume.pdf",
    "job_id": "12345"
  }'
```

Or use the test script:
```bash
BASE_URL=$API_URL ./test.sh all
```

## Step 6: Deploy to Production

When ready for production:

```bash
serverless deploy --stage prod
```

This creates a separate stack with production configuration.

## Step 7: Set Up API Gateway Custom Domain (Optional)

### Create Certificate in ACM

```bash
# Request certificate (must be in us-east-1 for API Gateway)
aws acm request-certificate \
    --domain-name api.yourdomain.com \
    --validation-method DNS \
    --region us-east-1
```

### Update serverless.yml

Add custom domain configuration:

```yaml
custom:
  customDomain:
    domainName: api.yourdomain.com
    basePath: ats
    stage: ${self:provider.stage}
    createRoute53Record: true
```

Install plugin:
```bash
npm install --save-dev serverless-domain-manager
```

Add to plugins in serverless.yml:
```yaml
plugins:
  - serverless-offline
  - serverless-python-requirements
  - serverless-domain-manager
```

Create domain:
```bash
serverless create_domain --stage prod
```

Deploy:
```bash
serverless deploy --stage prod
```

## Step 8: Configure Monitoring

### Enable CloudWatch Logs

CloudWatch logs are automatically enabled. View logs:

```bash
# View logs for a specific function
serverless logs -f getJobs --stage dev

# Tail logs in real-time
serverless logs -f getJobs --stage dev --tail
```

### Set Up Alarms

Create CloudWatch alarms for monitoring:

```bash
# Create alarm for errors
aws cloudwatch put-metric-alarm \
    --alarm-name ats-service-errors \
    --alarm-description "Alert on Lambda errors" \
    --metric-name Errors \
    --namespace AWS/Lambda \
    --statistic Sum \
    --period 300 \
    --threshold 5 \
    --comparison-operator GreaterThanThreshold \
    --evaluation-periods 1
```

## Step 9: Configure API Keys (Optional)

To secure your API with API keys:

### Update serverless.yml

```yaml
provider:
  apiGateway:
    apiKeys:
      - name: ats-api-key-${self:provider.stage}
    usagePlan:
      quota:
        limit: 5000
        period: MONTH
      throttle:
        burstLimit: 200
        rateLimit: 100

functions:
  getJobs:
    handler: src/handlers/jobs.get_jobs
    events:
      - http:
          path: jobs
          method: get
          cors: true
          private: true  # Require API key
```

Deploy and get API key:
```bash
serverless deploy --stage prod

# Get API key value
aws apigateway get-api-keys --include-values
```

Use API key in requests:
```bash
curl -X GET "$API_URL/jobs" \
  -H "x-api-key: your-api-key-here"
```

## Rollback

If deployment fails or you need to rollback:

```bash
# List deployments
serverless deploy list --stage dev

# Rollback to previous version
serverless rollback --timestamp <timestamp> --stage dev

# Remove deployment completely
serverless remove --stage dev
```

## Update Deployment

To update after code changes:

```bash
# Deploy all functions
serverless deploy --stage dev

# Deploy single function (faster)
serverless deploy function -f getJobs --stage dev
```

## Cost Optimization

### Lambda Reserved Concurrency

Limit concurrent executions to control costs:

```yaml
functions:
  getJobs:
    handler: src/handlers/jobs.get_jobs
    reservedConcurrency: 5
```

### API Gateway Caching

Enable caching to reduce Lambda invocations:

```yaml
provider:
  apiGateway:
    caching:
      enabled: true
      ttlInSeconds: 300  # 5 minutes
```

## Troubleshooting

### Issue: Deployment fails with "Unable to import module"

**Solution**: Ensure dependencies are packaged correctly
```bash
# Clean and redeploy
rm -rf node_modules .serverless
npm install
serverless deploy --stage dev
```

### Issue: "AccessDenied" errors

**Solution**: Check IAM permissions. Lambda needs:
- logs:CreateLogGroup
- logs:CreateLogStream
- logs:PutLogEvents
- ssm:GetParameter (if using Parameter Store)

### Issue: Timeouts

**Solution**: Increase timeout in serverless.yml
```yaml
provider:
  timeout: 30  # seconds
```

### Issue: Cold start latency

**Solution**: 
1. Keep functions warm with scheduled pings
2. Increase memory (faster CPU)
3. Use provisioned concurrency

## Security Checklist

- [ ] Credentials stored in AWS Secrets Manager/Parameter Store
- [ ] API Gateway has API keys or AWS IAM authentication
- [ ] CloudWatch logs enabled
- [ ] VPC configuration if needed
- [ ] HTTPS enforced
- [ ] CORS configured properly
- [ ] Error messages don't expose sensitive info

## Post-Deployment

1. **Test all endpoints** with real data
2. **Monitor CloudWatch metrics** for errors
3. **Set up alerts** for critical errors
4. **Document API endpoint URLs** for your team
5. **Update DNS records** if using custom domain
6. **Configure CI/CD** for automated deployments

## CI/CD Integration

Example GitHub Actions workflow:

```yaml
name: Deploy ATS Service

on:
  push:
    branches:
      - main

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Setup Node.js
        uses: actions/setup-node@v2
        with:
          node-version: '14'
      
      - name: Setup Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.11'
      
      - name: Install dependencies
        run: |
          npm install
          pip install -r requirements.txt
      
      - name: Deploy to AWS
        env:
          AWS_ACCESS_KEY_ID: ${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: ${{ secrets.AWS_SECRET_ACCESS_KEY }}
        run: |
          serverless deploy --stage prod
```

## Monitoring Dashboard

Create a CloudWatch dashboard to monitor your service:

```bash
aws cloudwatch put-dashboard \
    --dashboard-name ATS-Service \
    --dashboard-body file://dashboard.json
```

Sample dashboard.json:
```json
{
  "widgets": [
    {
      "type": "metric",
      "properties": {
        "metrics": [
          ["AWS/Lambda", "Invocations", {"stat": "Sum"}],
          [".", "Errors", {"stat": "Sum"}],
          [".", "Duration", {"stat": "Average"}]
        ],
        "period": 300,
        "region": "us-east-1",
        "title": "Lambda Metrics"
      }
    }
  ]
}
```

## Support

For issues or questions:
1. Check CloudWatch Logs
2. Review API Gateway execution logs
3. Test locally with `serverless offline`
4. Check AWS Service Health Dashboard

## Clean Up

To completely remove the deployment:

```bash
# Remove all resources
serverless remove --stage dev

# Delete SSM parameters
aws ssm delete-parameter --name "/ats-service/sf-api-url"
aws ssm delete-parameter --name "/ats-service/sf-company-id"
aws ssm delete-parameter --name "/ats-service/sf-username"
aws ssm delete-parameter --name "/ats-service/sf-password"
aws ssm delete-parameter --name "/ats-service/sf-api-key"
```
