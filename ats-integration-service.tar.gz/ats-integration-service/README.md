# ATS Integration Microservice - SAP SuccessFactors

A serverless microservice built with Python and AWS Lambda that provides a unified REST API for integrating with SAP SuccessFactors Applicant Tracking System (ATS).

## Table of Contents

- [Features](#features)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [SAP SuccessFactors Setup](#sap-successfactors-setup)
- [Installation](#installation)
- [Configuration](#configuration)
- [Local Development](#local-development)
- [API Endpoints](#api-endpoints)
- [Deployment](#deployment)
- [Testing](#testing)
- [Error Handling](#error-handling)
- [Troubleshooting](#troubleshooting)

## Features

- ✅ **Get Jobs**: Retrieve open job requisitions from SuccessFactors
- ✅ **Create Candidates**: Create candidates and submit applications
- ✅ **Get Applications**: List applications with filtering and pagination
- ✅ **Serverless Architecture**: Built on AWS Lambda for scalability
- ✅ **Error Handling**: Comprehensive error handling and validation
- ✅ **Pagination Support**: Handle large datasets efficiently
- ✅ **Standard API Format**: Unified JSON format across all endpoints

## Architecture

```
┌─────────────┐     HTTP/REST     ┌──────────────────┐
│   Client    │ ◄────────────────► │  API Gateway     │
│ (Postman)   │                    │  (AWS/Local)     │
└─────────────┘                    └────────┬─────────┘
                                            │
                                            │ Invoke
                                            │
                        ┌───────────────────┴───────────────────┐
                        │                                       │
                   ┌────▼────┐      ┌──────────┐      ┌───────▼──────┐
                   │  GET    │      │   POST   │      │     GET      │
                   │  /jobs  │      │/candidates│     │/applications │
                   └────┬────┘      └─────┬────┘      └───────┬──────┘
                        │                 │                   │
                        └─────────────────┼───────────────────┘
                                          │
                                ┌─────────▼──────────┐
                                │ SuccessFactors     │
                                │  Client Service    │
                                └─────────┬──────────┘
                                          │
                                          │ OData v2
                                          │
                                ┌─────────▼──────────┐
                                │  SAP SuccessFactors│
                                │   Recruiting API   │
                                └────────────────────┘
```

## Prerequisites

- **Python**: 3.11 or higher
- **Node.js**: 14.x or higher (for Serverless Framework)
- **AWS Account**: For deployment (optional for local dev)
- **SAP SuccessFactors**: Trial or production account with API access

## SAP SuccessFactors Setup

### Step 1: Create a Trial Account

1. Go to [SAP SuccessFactors Trial](https://www.sap.com/products/hcm/trial.html)
2. Click "Start Your Free Trial"
3. Fill out the registration form
4. You'll receive an email with your instance URL and credentials

### Step 2: Access Your Instance

Your instance URL will be in the format:
```
https://apisalesdemo8.successfactors.com
```

Or for EU datacenter:
```
https://apisalesdemo8.successfactors.eu
```

### Step 3: Generate API Credentials

1. Log into your SuccessFactors instance
2. Navigate to **Admin Center** → **Company Settings** → **API Center**
3. Generate an **OAuth Client**:
   - Client ID: Save this value
   - Client Secret: Save this value (shown only once)

### Step 4: Get API User Credentials

For simpler integration, you can use Basic Authentication:

1. Go to **Admin Center** → **Manage Users**
2. Find or create an API user
3. Set/Note the username and password
4. Ensure the user has permissions:
   - Recruiting Permissions
   - OData API Access
   - Job Requisition Management
   - Candidate Management

### Step 5: Find Your Company ID

1. In Admin Center, go to **Company Settings**
2. Look for "Company ID" (usually starts with `SFPART` or similar)
3. Note this value

### API Endpoints Reference

SuccessFactors uses OData v2 API:
```
Base URL: https://{instance}.successfactors.com/odata/v2/
```

Common entities:
- `/JobRequisition` - Job postings
- `/Candidate` - Candidate profiles
- `/JobApplication` - Applications linking candidates to jobs
- `/Attachment` - Resume and document attachments

## Installation

### 1. Clone or Download the Project

```bash
cd ats-integration-service
```

### 2. Install Python Dependencies

```bash
# Create virtual environment (recommended)
python -m venv venv

# Activate virtual environment
# On Windows:
venv\Scripts\activate
# On macOS/Linux:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Install Node.js Dependencies

```bash
npm install
```

## Configuration

### 1. Create Environment File

Copy the example environment file:

```bash
cp .env.example .env
```

### 2. Configure Environment Variables

Edit `.env` with your SuccessFactors credentials:

```bash
# SAP SuccessFactors Configuration
SF_API_URL=https://apisalesdemo8.successfactors.com
SF_COMPANY_ID=SFPART000000
SF_USERNAME=your-api-username
SF_PASSWORD=your-api-password
SF_API_KEY=your-oauth-client-id  # Optional for OAuth

# AWS Configuration (for deployment)
AWS_REGION=us-east-1
AWS_PROFILE=default
```

### Environment Variables Explained

| Variable | Description | Example |
|----------|-------------|---------|
| `SF_API_URL` | Base URL of your SF instance | `https://apisalesdemo8.successfactors.com` |
| `SF_COMPANY_ID` | Your company identifier | `SFPART000000` |
| `SF_USERNAME` | API user username | `api_user@company` |
| `SF_PASSWORD` | API user password | `YourSecurePassword123` |
| `SF_API_KEY` | OAuth client ID (optional) | `abc123xyz789` |

## Local Development

### Start the Local Server

```bash
# Make sure you're in the project directory with activated venv
npm start

# Or using serverless directly
serverless offline start
```

The API will be available at: `http://localhost:3000`

### Verify Server is Running

```bash
curl http://localhost:3000/jobs
```

## API Endpoints

### 1. GET /jobs

Retrieve open job requisitions from SuccessFactors.

**Query Parameters:**
- `status` (optional): Filter by status - `OPEN`, `CLOSED`, `DRAFT`
- `skip` (optional): Number of records to skip (default: 0)
- `limit` (optional): Number of records to return (default: 100, max: 100)

**Example Request:**
```bash
curl -X GET "http://localhost:3000/jobs?status=OPEN&limit=10"
```

**Example Response:**
```json
{
  "jobs": [
    {
      "id": "12345",
      "title": "Senior Software Engineer",
      "location": "USA",
      "status": "OPEN",
      "external_url": "https://careers.company.com/job/12345"
    },
    {
      "id": "12346",
      "title": "Product Manager",
      "location": "USA",
      "status": "OPEN",
      "external_url": "https://careers.company.com/job/12346"
    }
  ],
  "count": 2,
  "skip": 0,
  "limit": 10,
  "has_more": false
}
```

### 2. POST /candidates

Create a new candidate and submit their application to a job.

**Request Body:**
```json
{
  "name": "John Doe",
  "email": "john.doe@email.com",
  "phone": "+1-555-0100",
  "resume_url": "https://example.com/resumes/johndoe.pdf",
  "job_id": "12345"
}
```

**Example Request:**
```bash
curl -X POST "http://localhost:3000/candidates" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john.doe@email.com",
    "phone": "+1-555-0100",
    "resume_url": "https://example.com/resumes/johndoe.pdf",
    "job_id": "12345"
  }'
```

**Example Response:**
```json
{
  "candidate_id": "98765",
  "application_id": "54321",
  "job_id": "12345",
  "message": "Candidate created and application submitted successfully",
  "candidate": {
    "name": "John Doe",
    "email": "john.doe@email.com",
    "phone": "+1-555-0100"
  }
}
```

**Validation:**
- `name`: Required, minimum 1 character
- `email`: Required, must be valid email format
- `phone`: Required, minimum 10 digits
- `resume_url`: Required, must be valid HTTP/HTTPS URL
- `job_id`: Required

### 3. GET /applications

Retrieve job applications, optionally filtered by job ID.

**Query Parameters:**
- `job_id` (optional): Filter by job requisition ID
- `skip` (optional): Number of records to skip (default: 0)
- `limit` (optional): Number of records to return (default: 100, max: 100)

**Example Request:**
```bash
curl -X GET "http://localhost:3000/applications?job_id=12345&limit=20"
```

**Example Response:**
```json
{
  "applications": [
    {
      "id": "54321",
      "candidate_name": "John Doe",
      "email": "john.doe@email.com",
      "status": "APPLIED",
      "applied_date": "2024-01-15T10:30:00"
    },
    {
      "id": "54322",
      "candidate_name": "Jane Smith",
      "email": "jane.smith@email.com",
      "status": "SCREENING",
      "applied_date": "2024-01-14T14:20:00"
    }
  ],
  "count": 2,
  "skip": 0,
  "limit": 20,
  "has_more": false,
  "filters": {
    "job_id": "12345"
  }
}
```

**Status Values:**
- `APPLIED`: Application submitted
- `SCREENING`: Under review/interview process
- `REJECTED`: Application rejected
- `HIRED`: Candidate hired

## Deployment

### Deploy to AWS

1. **Configure AWS Credentials:**

```bash
# Using AWS CLI
aws configure

# Or set environment variables
export AWS_ACCESS_KEY_ID=your-access-key
export AWS_SECRET_ACCESS_KEY=your-secret-key
export AWS_REGION=us-east-1
```

2. **Set Environment Variables for Lambda:**

Edit `serverless.yml` to use AWS Systems Manager Parameter Store or AWS Secrets Manager:

```yaml
provider:
  environment:
    SF_API_URL: ${ssm:/ats-service/sf-api-url}
    SF_COMPANY_ID: ${ssm:/ats-service/sf-company-id}
    SF_USERNAME: ${ssm:/ats-service/sf-username~true}  # encrypted
    SF_PASSWORD: ${ssm:/ats-service/sf-password~true}  # encrypted
```

3. **Deploy:**

```bash
# Deploy to dev stage
serverless deploy --stage dev

# Deploy to production
serverless deploy --stage prod
```

4. **Note the API Endpoint:**

After deployment, Serverless will output your API Gateway URLs:

```
endpoints:
  GET - https://abc123.execute-api.us-east-1.amazonaws.com/dev/jobs
  POST - https://abc123.execute-api.us-east-1.amazonaws.com/dev/candidates
  GET - https://abc123.execute-api.us-east-1.amazonaws.com/dev/applications
```

## Testing

### Using cURL

**Get Jobs:**
```bash
curl -X GET "https://your-api-gateway-url/dev/jobs"
```

**Create Candidate:**
```bash
curl -X POST "https://your-api-gateway-url/dev/candidates" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Test Candidate",
    "email": "test@example.com",
    "phone": "+1-555-0199",
    "resume_url": "https://example.com/resume.pdf",
    "job_id": "12345"
  }'
```

**Get Applications:**
```bash
curl -X GET "https://your-api-gateway-url/dev/applications?job_id=12345"
```

### Using Postman

1. **Import Collection:**
   - Create a new collection in Postman
   - Add the three endpoints above

2. **Set Variables:**
   - `base_url`: Your API Gateway URL or `http://localhost:3000`

3. **Test Each Endpoint:**
   - GET Jobs
   - POST Candidates
   - GET Applications

### Sample Postman Collection

```json
{
  "info": {
    "name": "ATS Integration API",
    "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"
  },
  "variable": [
    {
      "key": "base_url",
      "value": "http://localhost:3000"
    }
  ],
  "item": [
    {
      "name": "Get Jobs",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/jobs?status=OPEN&limit=10"
      }
    },
    {
      "name": "Create Candidate",
      "request": {
        "method": "POST",
        "url": "{{base_url}}/candidates",
        "header": [
          {
            "key": "Content-Type",
            "value": "application/json"
          }
        ],
        "body": {
          "mode": "raw",
          "raw": "{\n  \"name\": \"John Doe\",\n  \"email\": \"john@example.com\",\n  \"phone\": \"+1-555-0100\",\n  \"resume_url\": \"https://example.com/resume.pdf\",\n  \"job_id\": \"12345\"\n}"
        }
      }
    },
    {
      "name": "Get Applications",
      "request": {
        "method": "GET",
        "url": "{{base_url}}/applications?job_id=12345"
      }
    }
  ]
}
```

## Error Handling

The API returns standardized error responses:

### Error Response Format

```json
{
  "error": "ErrorType",
  "message": "Detailed error message",
  "status_code": 400
}
```

### Common Error Types

| Status Code | Error Type | Description |
|-------------|------------|-------------|
| 400 | ValidationError | Invalid request parameters or body |
| 401 | AuthenticationError | Invalid SuccessFactors credentials |
| 403 | ForbiddenError | Insufficient permissions |
| 404 | NotFoundError | Resource not found (e.g., job ID) |
| 409 | ConflictError | Resource already exists |
| 429 | RateLimitError | Too many requests |
| 500 | InternalServerError | Server or integration error |

### Example Error Responses

**Validation Error:**
```json
{
  "error": "ValidationError",
  "message": "Invalid request data: email: value is not a valid email address",
  "status_code": 400
}
```

**Authentication Error:**
```json
{
  "error": "AuthenticationError",
  "message": "Failed to authenticate with SuccessFactors",
  "status_code": 401
}
```

**Not Found Error:**
```json
{
  "error": "NotFoundError",
  "message": "Job requisition not found",
  "status_code": 404
}
```

## Troubleshooting

### Issue: "Authentication failed"

**Solution:**
- Verify your `SF_USERNAME`, `SF_PASSWORD`, and `SF_COMPANY_ID` are correct
- Check that the API user has proper permissions
- Ensure you're using the format: `username@companyId` for authentication

### Issue: "Module not found" errors

**Solution:**
```bash
# Reinstall dependencies
pip install -r requirements.txt

# Make sure you're in the virtual environment
source venv/bin/activate  # macOS/Linux
venv\Scripts\activate     # Windows
```

### Issue: "Cannot find module 'serverless-offline'"

**Solution:**
```bash
# Reinstall Node dependencies
npm install
```

### Issue: "No jobs returned" or empty results

**Solution:**
- Log into SuccessFactors and verify there are active job requisitions
- Check the job status - ensure they're marked as "Open"
- Try the API call without filters first
- Verify API user has read permissions for Job Requisitions

### Issue: Rate limit errors (429)

**Solution:**
- The service automatically retries with exponential backoff
- Reduce the frequency of API calls
- Consider implementing caching for frequently accessed data

### Issue: Resume attachment fails

**Solution:**
- Resume attachment is optional and logged as a warning
- Ensure the `resume_url` is publicly accessible
- Check that the URL returns a valid PDF or document
- For production, implement actual file download and upload

## Project Structure

```
ats-integration-service/
├── src/
│   ├── handlers/
│   │   ├── __init__.py
│   │   ├── jobs.py              # GET /jobs handler
│   │   ├── candidates.py        # POST /candidates handler
│   │   └── applications.py      # GET /applications handler
│   ├── services/
│   │   ├── __init__.py
│   │   └── successfactors_client.py  # SF API client
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py           # Pydantic models
│   ├── utils/
│   │   ├── __init__.py
│   │   └── helpers.py           # Utility functions
│   └── __init__.py
├── serverless.yml               # Serverless Framework config
├── requirements.txt             # Python dependencies
├── package.json                 # Node.js dependencies
├── .env.example                 # Environment template
├── .env                         # Your credentials (gitignored)
└── README.md                    # This file
```

## Best Practices

1. **Security:**
   - Never commit `.env` file to version control
   - Use AWS Secrets Manager or Parameter Store for production
   - Rotate API credentials regularly
   - Use HTTPS for all resume URLs

2. **Error Handling:**
   - Always check API responses
   - Implement retry logic for transient failures
   - Log errors for debugging

3. **Performance:**
   - Use pagination for large datasets
   - Cache frequently accessed data
   - Monitor Lambda execution times

4. **Data Validation:**
   - Validate all inputs before sending to SuccessFactors
   - Use Pydantic models for type safety
   - Sanitize user inputs

## Support & Resources

- **SAP SuccessFactors API Documentation**: [SAP API Business Hub](https://api.sap.com/package/SAPSuccessFactors)
- **Serverless Framework**: [serverless.com/framework/docs](https://www.serverless.com/framework/docs)
- **AWS Lambda**: [AWS Lambda Documentation](https://docs.aws.amazon.com/lambda)

## License

This project is provided as-is for educational and integration purposes.

## Contributing

Feel free to submit issues and enhancement requests!
