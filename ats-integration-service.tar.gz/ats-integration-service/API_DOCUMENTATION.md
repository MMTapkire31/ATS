# API Documentation

Complete API reference for the ATS Integration Service.

## Base URL

**Local Development:**
```
http://localhost:3000
```

**Production:**
```
https://your-api-gateway-url/prod
```

## Authentication

Currently uses service-level authentication with SuccessFactors. All endpoints are publicly accessible but can be secured with API Gateway API keys.

To add API key authentication, include header:
```
x-api-key: your-api-key-here
```

## Response Format

All responses are in JSON format with appropriate HTTP status codes.

### Success Response Structure

```json
{
  "data": {},
  "metadata": {}
}
```

### Error Response Structure

```json
{
  "error": "ErrorType",
  "message": "Detailed error description",
  "status_code": 400
}
```

## Rate Limiting

- **Default**: No rate limiting in local development
- **Production**: Configurable via API Gateway (recommended: 100 requests/second)

## Endpoints

---

## 1. Get Jobs

Retrieve job requisitions from SuccessFactors ATS.

### Request

```http
GET /jobs
```

### Query Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `status` | string | No | - | Filter by job status: `OPEN`, `CLOSED`, `DRAFT` |
| `skip` | integer | No | 0 | Number of records to skip (pagination) |
| `limit` | integer | No | 100 | Number of records to return (max: 100) |

### Response

**Status Code:** `200 OK`

```json
{
  "jobs": [
    {
      "id": "12345",
      "title": "Senior Software Engineer",
      "location": "USA",
      "status": "OPEN",
      "external_url": "https://careers.company.com/job/12345"
    }
  ],
  "count": 1,
  "skip": 0,
  "limit": 100,
  "has_more": false
}
```

### Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `jobs` | array | Array of job objects |
| `jobs[].id` | string | Unique job requisition ID |
| `jobs[].title` | string | Job title |
| `jobs[].location` | string | Job location (country) |
| `jobs[].status` | string | Job status: `OPEN`, `CLOSED`, or `DRAFT` |
| `jobs[].external_url` | string\|null | Public job posting URL |
| `count` | integer | Number of jobs in current response |
| `skip` | integer | Number of records skipped |
| `limit` | integer | Maximum records per page |
| `has_more` | boolean | Whether more records are available |

### Examples

**Get all open jobs:**
```bash
curl -X GET "http://localhost:3000/jobs?status=OPEN"
```

**Get jobs with pagination:**
```bash
curl -X GET "http://localhost:3000/jobs?skip=10&limit=5"
```

**Get only first 10 jobs:**
```bash
curl -X GET "http://localhost:3000/jobs?limit=10"
```

### Error Responses

**400 Bad Request** - Invalid parameters
```json
{
  "error": "ValidationError",
  "message": "Limit parameter must be between 1 and 100",
  "status_code": 400
}
```

**401 Unauthorized** - Authentication failed
```json
{
  "error": "AuthenticationError",
  "message": "Failed to authenticate with SuccessFactors",
  "status_code": 401
}
```

**500 Internal Server Error** - Server error
```json
{
  "error": "InternalServerError",
  "message": "Failed to retrieve jobs: Connection timeout",
  "status_code": 500
}
```

---

## 2. Create Candidate

Create a new candidate profile and submit an application to a job.

### Request

```http
POST /candidates
```

### Headers

```http
Content-Type: application/json
```

### Request Body

```json
{
  "name": "John Doe",
  "email": "john.doe@example.com",
  "phone": "+1-555-0100",
  "resume_url": "https://example.com/resumes/johndoe.pdf",
  "job_id": "12345"
}
```

### Request Body Fields

| Field | Type | Required | Validation | Description |
|-------|------|----------|------------|-------------|
| `name` | string | Yes | Min 1 char | Full name of candidate |
| `email` | string | Yes | Valid email | Email address |
| `phone` | string | Yes | Min 10 digits | Phone number (any format) |
| `resume_url` | string | Yes | Valid HTTP/HTTPS URL | URL to candidate's resume |
| `job_id` | string | Yes | - | Job requisition ID to apply for |

### Response

**Status Code:** `201 Created`

```json
{
  "candidate_id": "98765",
  "application_id": "54321",
  "job_id": "12345",
  "message": "Candidate created and application submitted successfully",
  "candidate": {
    "name": "John Doe",
    "email": "john.doe@example.com",
    "phone": "+1-555-0100"
  }
}
```

### Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `candidate_id` | string | Unique candidate ID in SuccessFactors |
| `application_id` | string | Unique application ID |
| `job_id` | string | Job requisition ID applied to |
| `message` | string | Success message |
| `candidate` | object | Created candidate details |

### Examples

**Create candidate with all fields:**
```bash
curl -X POST http://localhost:3000/candidates \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jane Smith",
    "email": "jane.smith@example.com",
    "phone": "+1-555-0200",
    "resume_url": "https://storage.example.com/resumes/jane-smith.pdf",
    "job_id": "67890"
  }'
```

**JavaScript/Node.js example:**
```javascript
const response = await fetch('http://localhost:3000/candidates', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    name: 'Jane Smith',
    email: 'jane.smith@example.com',
    phone: '+1-555-0200',
    resume_url: 'https://example.com/resume.pdf',
    job_id: '67890'
  })
});

const data = await response.json();
console.log(data);
```

**Python example:**
```python
import requests

response = requests.post(
    'http://localhost:3000/candidates',
    json={
        'name': 'Jane Smith',
        'email': 'jane.smith@example.com',
        'phone': '+1-555-0200',
        'resume_url': 'https://example.com/resume.pdf',
        'job_id': '67890'
    }
)

data = response.json()
print(data)
```

### Error Responses

**400 Bad Request** - Validation error
```json
{
  "error": "ValidationError",
  "message": "Invalid request data: email: value is not a valid email address",
  "status_code": 400
}
```

**404 Not Found** - Job not found
```json
{
  "error": "NotFoundError",
  "message": "Job requisition not found",
  "status_code": 404
}
```

**409 Conflict** - Duplicate candidate
```json
{
  "error": "ConflictError",
  "message": "Candidate with this email may already exist",
  "status_code": 409
}
```

---

## 3. Get Applications

Retrieve job applications, optionally filtered by job ID.

### Request

```http
GET /applications
```

### Query Parameters

| Parameter | Type | Required | Default | Description |
|-----------|------|----------|---------|-------------|
| `job_id` | string | No | - | Filter applications by job requisition ID |
| `skip` | integer | No | 0 | Number of records to skip (pagination) |
| `limit` | integer | No | 100 | Number of records to return (max: 100) |

### Response

**Status Code:** `200 OK`

```json
{
  "applications": [
    {
      "id": "54321",
      "candidate_name": "John Doe",
      "email": "john.doe@example.com",
      "status": "APPLIED",
      "applied_date": "2024-01-15T10:30:00"
    }
  ],
  "count": 1,
  "skip": 0,
  "limit": 100,
  "has_more": false,
  "filters": {
    "job_id": "12345"
  }
}
```

### Response Fields

| Field | Type | Description |
|-------|------|-------------|
| `applications` | array | Array of application objects |
| `applications[].id` | string | Unique application ID |
| `applications[].candidate_name` | string | Candidate's full name |
| `applications[].email` | string | Candidate's email |
| `applications[].status` | string | Application status |
| `applications[].applied_date` | string\|null | ISO 8601 timestamp |
| `count` | integer | Number of applications in response |
| `skip` | integer | Number of records skipped |
| `limit` | integer | Maximum records per page |
| `has_more` | boolean | Whether more records available |
| `filters` | object | Applied filters |

### Application Status Values

| Status | Description |
|--------|-------------|
| `APPLIED` | Application submitted, pending review |
| `SCREENING` | Under review, in interview process, or offer extended |
| `REJECTED` | Application rejected or declined |
| `HIRED` | Candidate hired |

### Examples

**Get all applications:**
```bash
curl -X GET "http://localhost:3000/applications"
```

**Get applications for specific job:**
```bash
curl -X GET "http://localhost:3000/applications?job_id=12345"
```

**Get applications with pagination:**
```bash
curl -X GET "http://localhost:3000/applications?job_id=12345&skip=10&limit=20"
```

### Error Responses

**400 Bad Request** - Invalid parameters
```json
{
  "error": "ValidationError",
  "message": "Skip parameter must be non-negative",
  "status_code": 400
}
```

**404 Not Found** - Job not found
```json
{
  "error": "NotFoundError",
  "message": "Job requisition not found",
  "status_code": 404
}
```

---

## Data Models

### Job Model

```typescript
interface Job {
  id: string;                    // Unique identifier
  title: string;                 // Job title
  location: string;              // Job location
  status: "OPEN" | "CLOSED" | "DRAFT";  // Job status
  external_url: string | null;   // Public posting URL
}
```

### Candidate Request Model

```typescript
interface CandidateRequest {
  name: string;        // Full name (min 1 char)
  email: string;       // Valid email address
  phone: string;       // Phone (min 10 digits)
  resume_url: string;  // Valid HTTP/HTTPS URL
  job_id: string;      // Job to apply for
}
```

### Application Model

```typescript
interface Application {
  id: string;                // Unique identifier
  candidate_name: string;    // Candidate's name
  email: string;             // Candidate's email
  status: ApplicationStatus; // Current status
  applied_date: string | null;  // ISO 8601 timestamp
}

type ApplicationStatus = 
  | "APPLIED" 
  | "SCREENING" 
  | "REJECTED" 
  | "HIRED";
```

---

## HTTP Status Codes

| Code | Meaning | When Used |
|------|---------|-----------|
| 200 | OK | Successful GET request |
| 201 | Created | Successful POST request |
| 400 | Bad Request | Invalid request parameters or body |
| 401 | Unauthorized | Authentication failed |
| 403 | Forbidden | Insufficient permissions |
| 404 | Not Found | Resource not found |
| 409 | Conflict | Resource already exists |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | Server or integration error |

---

## Best Practices

### Pagination

Always use pagination for large datasets:

```bash
# First page
curl "http://localhost:3000/jobs?limit=20&skip=0"

# Second page
curl "http://localhost:3000/jobs?limit=20&skip=20"

# Third page
curl "http://localhost:3000/jobs?limit=20&skip=40"
```

### Error Handling

Always check the status code and handle errors:

```javascript
try {
  const response = await fetch('http://localhost:3000/candidates', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(candidateData)
  });
  
  if (!response.ok) {
    const error = await response.json();
    console.error(`Error ${error.status_code}: ${error.message}`);
    return;
  }
  
  const data = await response.json();
  console.log('Success:', data);
} catch (error) {
  console.error('Network error:', error);
}
```

### Rate Limiting

Implement exponential backoff for 429 errors:

```javascript
async function fetchWithRetry(url, options, maxRetries = 3) {
  for (let i = 0; i < maxRetries; i++) {
    const response = await fetch(url, options);
    
    if (response.status !== 429) {
      return response;
    }
    
    // Wait before retrying
    await new Promise(resolve => 
      setTimeout(resolve, Math.pow(2, i) * 1000)
    );
  }
  
  throw new Error('Max retries exceeded');
}
```

---

## Webhooks (Future Enhancement)

Currently not implemented. Future versions may include:

- Job status change notifications
- Application status updates
- Candidate profile updates

---

## Changelog

### Version 1.0.0 (Current)
- Initial release
- GET /jobs endpoint
- POST /candidates endpoint
- GET /applications endpoint
- Basic pagination support
- Error handling and validation

---

## Support

For API support:
- Review this documentation
- Check the README.md for setup instructions
- Review CloudWatch logs for errors
- Test locally with `serverless offline`

## License

This API is provided as-is for integration purposes.
