#!/bin/bash

# ATS Integration Service - Test Script
# This script provides easy commands to test the API endpoints

BASE_URL="${BASE_URL:-http://localhost:3000}"

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}=== ATS Integration Service Test Script ===${NC}\n"

# Function to test GET /jobs
test_get_jobs() {
    echo -e "${GREEN}Testing GET /jobs${NC}"
    echo "Request: GET $BASE_URL/jobs"
    echo ""
    curl -X GET "$BASE_URL/jobs" \
        -H "Content-Type: application/json" \
        | python -m json.tool
    echo -e "\n"
}

# Function to test GET /jobs with filters
test_get_jobs_filtered() {
    echo -e "${GREEN}Testing GET /jobs with status filter${NC}"
    echo "Request: GET $BASE_URL/jobs?status=OPEN&limit=5"
    echo ""
    curl -X GET "$BASE_URL/jobs?status=OPEN&limit=5" \
        -H "Content-Type: application/json" \
        | python -m json.tool
    echo -e "\n"
}

# Function to test POST /candidates
test_post_candidate() {
    local JOB_ID=$1
    
    if [ -z "$JOB_ID" ]; then
        echo -e "${RED}Error: Job ID required${NC}"
        echo "Usage: $0 post_candidate <job_id>"
        return 1
    fi
    
    echo -e "${GREEN}Testing POST /candidates${NC}"
    echo "Request: POST $BASE_URL/candidates"
    echo ""
    
    TIMESTAMP=$(date +%s)
    
    curl -X POST "$BASE_URL/candidates" \
        -H "Content-Type: application/json" \
        -d "{
            \"name\": \"Test Candidate $TIMESTAMP\",
            \"email\": \"test.$TIMESTAMP@example.com\",
            \"phone\": \"+1-555-0$((RANDOM % 1000))\",
            \"resume_url\": \"https://example.com/resumes/test_$TIMESTAMP.pdf\",
            \"job_id\": \"$JOB_ID\"
        }" \
        | python -m json.tool
    echo -e "\n"
}

# Function to test GET /applications
test_get_applications() {
    echo -e "${GREEN}Testing GET /applications${NC}"
    echo "Request: GET $BASE_URL/applications"
    echo ""
    curl -X GET "$BASE_URL/applications" \
        -H "Content-Type: application/json" \
        | python -m json.tool
    echo -e "\n"
}

# Function to test GET /applications with job filter
test_get_applications_by_job() {
    local JOB_ID=$1
    
    if [ -z "$JOB_ID" ]; then
        echo -e "${RED}Error: Job ID required${NC}"
        echo "Usage: $0 applications_by_job <job_id>"
        return 1
    fi
    
    echo -e "${GREEN}Testing GET /applications?job_id=$JOB_ID${NC}"
    echo "Request: GET $BASE_URL/applications?job_id=$JOB_ID"
    echo ""
    curl -X GET "$BASE_URL/applications?job_id=$JOB_ID" \
        -H "Content-Type: application/json" \
        | python -m json.tool
    echo -e "\n"
}

# Function to run all tests
test_all() {
    echo -e "${BLUE}Running all tests...${NC}\n"
    
    # Test GET /jobs
    test_get_jobs
    
    # Test GET /jobs with filter
    test_get_jobs_filtered
    
    # Test GET /applications
    test_get_applications
    
    echo -e "${BLUE}=== Tests Complete ===${NC}"
    echo -e "${BLUE}Note: POST /candidates test requires a valid job_id${NC}"
    echo -e "${BLUE}Run: ./test.sh post_candidate <job_id>${NC}\n"
}

# Main script logic
case "$1" in
    jobs)
        test_get_jobs
        ;;
    jobs_filtered)
        test_get_jobs_filtered
        ;;
    post_candidate)
        test_post_candidate "$2"
        ;;
    applications)
        test_get_applications
        ;;
    applications_by_job)
        test_get_applications_by_job "$2"
        ;;
    all)
        test_all
        ;;
    *)
        echo "Usage: $0 {jobs|jobs_filtered|post_candidate <job_id>|applications|applications_by_job <job_id>|all}"
        echo ""
        echo "Examples:"
        echo "  $0 jobs                          # Test GET /jobs"
        echo "  $0 jobs_filtered                 # Test GET /jobs with filters"
        echo "  $0 post_candidate 12345          # Test POST /candidates"
        echo "  $0 applications                  # Test GET /applications"
        echo "  $0 applications_by_job 12345     # Test GET /applications?job_id=12345"
        echo "  $0 all                           # Run all GET tests"
        echo ""
        echo "Set BASE_URL environment variable to test deployed API:"
        echo "  BASE_URL=https://your-api.execute-api.us-east-1.amazonaws.com/dev $0 all"
        exit 1
        ;;
esac
