# Quick Start Guide

Get the ATS Integration Service up and running in 5 minutes!

## Step 1: Install Dependencies (2 minutes)

```bash
# Install Node.js dependencies
npm install

# Create and activate Python virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install Python dependencies
pip install -r requirements.txt
```

## Step 2: Configure Environment (1 minute)

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your credentials
nano .env  # or use your preferred editor
```

Required values in `.env`:
```bash
SF_API_URL=https://your-instance.successfactors.com
SF_COMPANY_ID=YOURCOMPANYID
SF_USERNAME=your-username
SF_PASSWORD=your-password
```

## Step 3: Start Local Server (30 seconds)

```bash
npm start
```

You should see:
```
offline: Starting Offline: dev/us-east-1.
offline: Offline [http for lambda] listening on http://localhost:3002
offline: Function names exposed for local invocation by aws-sdk:
           * getJobs: ats-integration-service-dev-getJobs
           * postCandidate: ats-integration-service-dev-postCandidate
           * getApplications: ats-integration-service-dev-getApplications

   ┌─────────────────────────────────────────────────────────────────────────┐
   │                                                                         │
   │   GET  | http://localhost:3000/jobs                                    │
   │   POST | http://localhost:3000/candidates                              │
   │   GET  | http://localhost:3000/applications                            │
   │                                                                         │
   └─────────────────────────────────────────────────────────────────────────┘

offline: [HTTP] server ready: http://localhost:3000 🚀
```

## Step 4: Test the API (1 minute)

### Option A: Using cURL

```bash
# Get jobs
curl http://localhost:3000/jobs

# Get applications
curl http://localhost:3000/applications
```

### Option B: Using Test Script

```bash
# Make script executable
chmod +x test.sh

# Run all tests
./test.sh all
```

### Option C: Using Postman

1. Import `postman_collection.json`
2. Set `base_url` variable to `http://localhost:3000`
3. Run the requests

## Common First-Time Issues

### Issue: "Module not found" error

```bash
# Reinstall dependencies
pip install -r requirements.txt
```

### Issue: "Cannot find serverless-offline"

```bash
# Reinstall Node modules
npm install
```

### Issue: "Authentication failed"

- Check your `.env` file has correct credentials
- Verify username format: `username@companyId` or just `username`
- Test login to SuccessFactors web interface first

### Issue: No jobs returned

- Log into SuccessFactors and create a test job requisition
- Set status to "Open"
- Wait a few minutes for changes to sync

## Next Steps

1. **Read the full README.md** for detailed documentation
2. **Review API endpoints** and response formats
3. **Test with real data** from your SuccessFactors instance
4. **Deploy to AWS** when ready (see DEPLOYMENT.md)

## Quick API Reference

### GET /jobs
```bash
curl "http://localhost:3000/jobs?status=OPEN&limit=10"
```

### POST /candidates
```bash
curl -X POST http://localhost:3000/candidates \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "+1-555-0100",
    "resume_url": "https://example.com/resume.pdf",
    "job_id": "12345"
  }'
```

### GET /applications
```bash
curl "http://localhost:3000/applications?job_id=12345"
```

## Need Help?

- 📖 See **README.md** for full documentation
- 🚀 See **DEPLOYMENT.md** for AWS deployment guide
- 🐛 Check CloudWatch logs for errors
- 💡 Review SAP SuccessFactors API documentation

## What's Next?

- **Customize**: Modify handlers to fit your specific needs
- **Enhance**: Add authentication, caching, or additional endpoints
- **Deploy**: Push to AWS Lambda for production use
- **Monitor**: Set up CloudWatch alarms and dashboards

Happy coding! 🎉
