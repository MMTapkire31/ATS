"""
Utility functions for API handlers
"""
import json
from typing import Dict, Any, List, Optional


def create_response(
    status_code: int, 
    body: Dict[str, Any],
    headers: Optional[Dict[str, str]] = None
) -> Dict[str, Any]:
    """
    Create a standardized API Gateway response
    
    Args:
        status_code: HTTP status code
        body: Response body dictionary
        headers: Optional additional headers
        
    Returns:
        API Gateway response dictionary
    """
    default_headers = {
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Credentials': True,
    }
    
    if headers:
        default_headers.update(headers)
    
    return {
        'statusCode': status_code,
        'headers': default_headers,
        'body': json.dumps(body)
    }


def create_error_response(
    status_code: int,
    error_type: str,
    message: str
) -> Dict[str, Any]:
    """
    Create a standardized error response
    
    Args:
        status_code: HTTP status code
        error_type: Type of error
        message: Error message
        
    Returns:
        API Gateway error response
    """
    return create_response(
        status_code=status_code,
        body={
            'error': error_type,
            'message': message,
            'status_code': status_code
        }
    )


def transform_sf_job_to_standard(sf_job: Dict[str, Any]) -> Dict[str, Any]:
    """
    Transform SuccessFactors job format to standard API format
    
    Args:
        sf_job: SuccessFactors job data
        
    Returns:
        Standardized job dictionary
    """
    # Map SuccessFactors status to standard status
    status_mapping = {
        'Open': 'OPEN',
        'Closed': 'CLOSED',
        'Draft': 'DRAFT',
        'Approved': 'OPEN',
        'Pending': 'DRAFT'
    }
    
    sf_status = sf_job.get('status', 'Draft')
    standard_status = status_mapping.get(sf_status, 'DRAFT')
    
    # Get title from locale data if available
    title = sf_job.get('positionTitle', 'Untitled Position')
    if 'jobReqLocale' in sf_job and isinstance(sf_job['jobReqLocale'], dict):
        title = sf_job['jobReqLocale'].get('jobReqTitle', title)
    
    return {
        'id': str(sf_job.get('jobReqId', '')),
        'title': title,
        'location': sf_job.get('country', 'Not specified'),
        'status': standard_status,
        'external_url': sf_job.get('externalPostingURL', None)
    }


def transform_sf_application_to_standard(
    sf_application: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Transform SuccessFactors application format to standard API format
    
    Args:
        sf_application: SuccessFactors application data
        
    Returns:
        Standardized application dictionary
    """
    # Map SuccessFactors status to standard status
    status_mapping = {
        'New': 'APPLIED',
        'In Progress': 'SCREENING',
        'Under Review': 'SCREENING',
        'Screening': 'SCREENING',
        'Interview': 'SCREENING',
        'Rejected': 'REJECTED',
        'Declined': 'REJECTED',
        'Hired': 'HIRED',
        'Offer': 'SCREENING'
    }
    
    sf_status = sf_application.get('status', 'New')
    standard_status = status_mapping.get(sf_status, 'APPLIED')
    
    # Extract candidate information
    candidate_name = 'Unknown'
    candidate_email = ''
    
    if 'candidate' in sf_application and isinstance(sf_application['candidate'], dict):
        candidate = sf_application['candidate']
        first_name = candidate.get('firstName', '')
        last_name = candidate.get('lastName', '')
        candidate_name = f"{first_name} {last_name}".strip() or 'Unknown'
        candidate_email = candidate.get('email', candidate.get('contactEmail', ''))
    
    return {
        'id': str(sf_application.get('applicationId', '')),
        'candidate_name': candidate_name,
        'email': candidate_email,
        'status': standard_status,
        'applied_date': sf_application.get('applicationDate', None)
    }


def extract_query_params(event: Dict[str, Any]) -> Dict[str, str]:
    """
    Extract and validate query parameters from API Gateway event
    
    Args:
        event: API Gateway event object
        
    Returns:
        Dictionary of query parameters
    """
    params = event.get('queryStringParameters') or {}
    return {k: v for k, v in params.items() if v is not None}


def extract_body(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Extract and parse body from API Gateway event
    
    Args:
        event: API Gateway event object
        
    Returns:
        Parsed body dictionary
        
    Raises:
        ValueError: If body is invalid JSON
    """
    body = event.get('body', '{}')
    
    if isinstance(body, str):
        try:
            return json.loads(body)
        except json.JSONDecodeError:
            raise ValueError("Invalid JSON in request body")
    
    return body


def paginate_results(
    items: List[Any],
    skip: int = 0,
    limit: int = 100
) -> Dict[str, Any]:
    """
    Apply pagination to a list of items
    
    Args:
        items: List of items to paginate
        skip: Number of items to skip
        limit: Maximum number of items to return
        
    Returns:
        Paginated response dictionary
    """
    total = len(items)
    start = min(skip, total)
    end = min(skip + limit, total)
    
    return {
        'data': items[start:end],
        'total': total,
        'skip': skip,
        'limit': limit,
        'has_more': end < total
    }
