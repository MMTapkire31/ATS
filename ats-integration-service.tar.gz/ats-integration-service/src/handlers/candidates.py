"""
Candidates Handler
Handles POST /candidates endpoint to create candidates and applications
"""
import json
from typing import Dict, Any
from pydantic import ValidationError
from src.services.successfactors_client import SuccessFactorsClient
from src.models.schemas import CandidateRequest
from src.utils.helpers import (
    create_response,
    create_error_response,
    extract_body
)


def post_candidate(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for POST /candidates
    
    Creates a new candidate in SuccessFactors and creates an application
    linking them to the specified job.
    
    Request Body:
        {
            "name": "string",
            "email": "string",
            "phone": "string",
            "resume_url": "string",
            "job_id": "string"
        }
        
    Returns:
        API Gateway response with created candidate/application data or error
    """
    try:
        # Extract and parse request body
        body = extract_body(event)
        
        # Validate request using Pydantic model
        try:
            candidate_request = CandidateRequest(**body)
        except ValidationError as e:
            # Extract validation errors
            errors = []
            for error in e.errors():
                field = '.'.join(str(x) for x in error['loc'])
                errors.append(f"{field}: {error['msg']}")
            
            return create_error_response(
                400,
                'ValidationError',
                f"Invalid request data: {'; '.join(errors)}"
            )
        
        # Initialize SuccessFactors client
        sf_client = SuccessFactorsClient()
        
        # Step 1: Create candidate in SuccessFactors
        print(f"Creating candidate: {candidate_request.name}")
        
        candidate_data = {
            'name': candidate_request.name,
            'email': candidate_request.email,
            'phone': candidate_request.phone
        }
        
        sf_candidate_response = sf_client.create_candidate(candidate_data)
        
        # Extract candidate ID from response
        candidate_id = sf_candidate_response.get('d', {}).get('candidateId')
        
        if not candidate_id:
            raise Exception("Failed to create candidate - no ID returned")
        
        print(f"Candidate created with ID: {candidate_id}")
        
        # Step 2: Attach resume to candidate (if URL provided)
        if candidate_request.resume_url:
            try:
                print(f"Attaching resume: {candidate_request.resume_url}")
                sf_client.attach_resume(candidate_id, candidate_request.resume_url)
            except Exception as e:
                # Log but don't fail - resume attachment is optional
                print(f"Warning: Failed to attach resume: {str(e)}")
        
        # Step 3: Create job application
        print(f"Creating application for job: {candidate_request.job_id}")
        
        sf_application_response = sf_client.create_job_application(
            candidate_id=candidate_id,
            job_req_id=candidate_request.job_id
        )
        
        # Extract application ID from response
        application_id = sf_application_response.get('d', {}).get('applicationId')
        
        if not application_id:
            raise Exception("Failed to create application - no ID returned")
        
        print(f"Application created with ID: {application_id}")
        
        # Build success response
        response_data = {
            'candidate_id': str(candidate_id),
            'application_id': str(application_id),
            'job_id': candidate_request.job_id,
            'message': 'Candidate created and application submitted successfully',
            'candidate': {
                'name': candidate_request.name,
                'email': candidate_request.email,
                'phone': candidate_request.phone
            }
        }
        
        return create_response(201, response_data)
        
    except ValueError as e:
        return create_error_response(
            400,
            'ValidationError',
            str(e)
        )
    
    except Exception as e:
        # Log the error
        print(f"Error in post_candidate: {str(e)}")
        
        # Check for specific error messages
        error_msg = str(e).lower()
        
        if 'authentication' in error_msg or 'unauthorized' in error_msg:
            return create_error_response(
                401,
                'AuthenticationError',
                'Failed to authenticate with SuccessFactors'
            )
        
        if 'not found' in error_msg or '404' in error_msg:
            return create_error_response(
                404,
                'NotFoundError',
                'Job requisition not found'
            )
        
        if 'duplicate' in error_msg or 'already exists' in error_msg:
            return create_error_response(
                409,
                'ConflictError',
                'Candidate with this email may already exist'
            )
        
        return create_error_response(
            500,
            'InternalServerError',
            f'Failed to create candidate: {str(e)}'
        )
