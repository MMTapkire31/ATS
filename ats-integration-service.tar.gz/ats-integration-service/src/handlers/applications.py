"""
Applications Handler
Handles GET /applications endpoint to retrieve job applications
"""
import json
from typing import Dict, Any
from src.services.successfactors_client import SuccessFactorsClient
from src.utils.helpers import (
    create_response,
    create_error_response,
    extract_query_params,
    transform_sf_application_to_standard
)


def get_applications(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for GET /applications
    
    Retrieves job applications from SuccessFactors, optionally filtered by job ID.
    
    Query Parameters:
        - job_id: Filter by job requisition ID - optional
        - skip: Number of records to skip for pagination - default 0
        - limit: Number of records to return - default 100, max 100
        
    Returns:
        API Gateway response with applications data or error
    """
    try:
        # Extract query parameters
        params = extract_query_params(event)
        job_id = params.get('job_id', None)
        skip = int(params.get('skip', 0))
        limit = int(params.get('limit', 100))
        
        # Validate pagination parameters
        if skip < 0:
            return create_error_response(
                400,
                'ValidationError',
                'Skip parameter must be non-negative'
            )
        
        if limit < 1 or limit > 100:
            return create_error_response(
                400,
                'ValidationError',
                'Limit parameter must be between 1 and 100'
            )
        
        # Initialize SuccessFactors client
        sf_client = SuccessFactorsClient()
        
        # Fetch applications from SuccessFactors
        print(f"Fetching applications for job_id: {job_id if job_id else 'all jobs'}")
        
        sf_response = sf_client.get_applications(
            job_req_id=job_id,
            skip=skip,
            top=limit
        )
        
        # Extract results from SuccessFactors response
        sf_applications = sf_response.get('d', {}).get('results', [])
        
        print(f"Retrieved {len(sf_applications)} applications from SuccessFactors")
        
        # Transform to standard format
        applications = []
        for sf_app in sf_applications:
            try:
                standard_app = transform_sf_application_to_standard(sf_app)
                applications.append(standard_app)
            except Exception as e:
                # Log but continue processing other applications
                print(f"Warning: Failed to transform application: {str(e)}")
                continue
        
        # Build response with pagination metadata
        response_data = {
            'applications': applications,
            'count': len(applications),
            'skip': skip,
            'limit': limit,
            'has_more': len(sf_applications) == limit,
            'filters': {}
        }
        
        if job_id:
            response_data['filters']['job_id'] = job_id
        
        return create_response(200, response_data)
        
    except ValueError as e:
        return create_error_response(
            400,
            'ValidationError',
            str(e)
        )
    
    except Exception as e:
        # Log the error
        print(f"Error in get_applications: {str(e)}")
        
        # Check for specific error messages
        error_msg = str(e).lower()
        
        if 'authentication' in error_msg or 'unauthorized' in error_msg:
            return create_error_response(
                401,
                'AuthenticationError',
                'Failed to authenticate with SuccessFactors'
            )
        
        if 'not found' in error_msg or '404' in error_msg:
            return create_error_response(
                404,
                'NotFoundError',
                'Job requisition not found'
            )
        
        return create_error_response(
            500,
            'InternalServerError',
            f'Failed to retrieve applications: {str(e)}'
        )
