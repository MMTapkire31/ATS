"""
Jobs Handler
Handles GET /jobs endpoint to retrieve job listings from SuccessFactors
"""
import json
from typing import Dict, Any
from src.services.successfactors_client import SuccessFactorsClient
from src.utils.helpers import (
    create_response, 
    create_error_response,
    extract_query_params,
    transform_sf_job_to_standard
)


def get_jobs(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Lambda handler for GET /jobs
    
    Retrieves open job requisitions from SuccessFactors and returns them
    in a standardized format.
    
    Query Parameters:
        - status: Filter by status (OPEN, CLOSED, DRAFT) - optional
        - skip: Number of records to skip for pagination - default 0
        - limit: Number of records to return - default 100, max 100
        
    Returns:
        API Gateway response with jobs data or error
    """
    try:
        # Extract query parameters
        params = extract_query_params(event)
        status = params.get('status', None)
        skip = int(params.get('skip', 0))
        limit = int(params.get('limit', 100))
        
        # Validate pagination parameters
        if skip < 0:
            return create_error_response(
                400, 
                'ValidationError',
                'Skip parameter must be non-negative'
            )
        
        if limit < 1 or limit > 100:
            return create_error_response(
                400,
                'ValidationError',
                'Limit parameter must be between 1 and 100'
            )
        
        # Validate status parameter if provided
        valid_statuses = ['OPEN', 'CLOSED', 'DRAFT']
        if status and status.upper() not in valid_statuses:
            return create_error_response(
                400,
                'ValidationError',
                f'Status must be one of: {", ".join(valid_statuses)}'
            )
        
        # Map standard status to SuccessFactors status
        sf_status_mapping = {
            'OPEN': 'Open',
            'CLOSED': 'Closed',
            'DRAFT': 'Draft'
        }
        sf_status = sf_status_mapping.get(status.upper()) if status else None
        
        # Initialize SuccessFactors client
        sf_client = SuccessFactorsClient()
        
        # Fetch jobs from SuccessFactors
        sf_response = sf_client.get_job_requisitions(
            status=sf_status,
            skip=skip,
            top=limit
        )
        
        # Extract results from SuccessFactors response
        sf_jobs = sf_response.get('d', {}).get('results', [])
        
        # Transform to standard format
        jobs = [transform_sf_job_to_standard(job) for job in sf_jobs]
        
        # Build response with pagination metadata
        response_data = {
            'jobs': jobs,
            'count': len(jobs),
            'skip': skip,
            'limit': limit,
            'has_more': len(jobs) == limit  # If we got full limit, there might be more
        }
        
        return create_response(200, response_data)
        
    except ValueError as e:
        return create_error_response(
            400,
            'ValidationError',
            str(e)
        )
    
    except Exception as e:
        # Log the error (in production, use proper logging)
        print(f"Error in get_jobs: {str(e)}")
        
        return create_error_response(
            500,
            'InternalServerError',
            f'Failed to retrieve jobs: {str(e)}'
        )
