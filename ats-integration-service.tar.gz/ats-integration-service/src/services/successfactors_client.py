"""
SAP SuccessFactors API Client
Handles authentication and API communication with SuccessFactors
"""
import os
import requests
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
import base64
import json


class SuccessFactorsClient:
    """Client for interacting with SAP SuccessFactors Recruiting API"""
    
    def __init__(self):
        self.api_url = os.getenv('SF_API_URL', '').rstrip('/')
        self.company_id = os.getenv('SF_COMPANY_ID', '')
        self.username = os.getenv('SF_USERNAME', '')
        self.password = os.getenv('SF_PASSWORD', '')
        self.api_key = os.getenv('SF_API_KEY', '')
        
        if not all([self.api_url, self.company_id, self.username]):
            raise ValueError("Missing required SuccessFactors configuration")
        
        self.session = requests.Session()
        self._setup_auth()
    
    def _setup_auth(self):
        """Setup authentication headers for API requests"""
        # SAP SuccessFactors uses Basic Auth
        auth_string = f"{self.username}@{self.company_id}:{self.password}"
        encoded_auth = base64.b64encode(auth_string.encode()).decode()
        
        self.session.headers.update({
            'Authorization': f'Basic {encoded_auth}',
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
        
        if self.api_key:
            self.session.headers.update({'apikey': self.api_key})
    
    def _make_request(
        self, 
        method: str, 
        endpoint: str, 
        params: Optional[Dict] = None,
        data: Optional[Dict] = None,
        retry: int = 3
    ) -> Dict[str, Any]:
        """
        Make HTTP request to SuccessFactors API with error handling
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            params: Query parameters
            data: Request body data
            retry: Number of retry attempts
            
        Returns:
            Response data as dictionary
            
        Raises:
            Exception: On API errors
        """
        url = f"{self.api_url}/odata/v2/{endpoint}"
        
        for attempt in range(retry):
            try:
                response = self.session.request(
                    method=method,
                    url=url,
                    params=params,
                    json=data,
                    timeout=30
                )
                
                # Handle successful responses
                if response.status_code in [200, 201]:
                    return response.json()
                
                # Handle specific error codes
                elif response.status_code == 401:
                    raise Exception("Authentication failed. Check credentials.")
                elif response.status_code == 403:
                    raise Exception("Access forbidden. Check API permissions.")
                elif response.status_code == 404:
                    raise Exception("Resource not found.")
                elif response.status_code == 429:
                    # Rate limit - wait and retry
                    if attempt < retry - 1:
                        import time
                        time.sleep(2 ** attempt)
                        continue
                    raise Exception("Rate limit exceeded.")
                else:
                    error_msg = f"API Error: {response.status_code}"
                    try:
                        error_data = response.json()
                        error_msg += f" - {error_data.get('error', {}).get('message', '')}"
                    except:
                        error_msg += f" - {response.text}"
                    raise Exception(error_msg)
                    
            except requests.exceptions.RequestException as e:
                if attempt < retry - 1:
                    continue
                raise Exception(f"Request failed: {str(e)}")
        
        raise Exception("Max retries exceeded")
    
    def get_job_requisitions(
        self, 
        status: Optional[str] = None,
        skip: int = 0,
        top: int = 100
    ) -> Dict[str, Any]:
        """
        Get job requisitions from SuccessFactors
        
        Args:
            status: Filter by status (e.g., 'Open', 'Closed')
            skip: Number of records to skip (pagination)
            top: Number of records to return
            
        Returns:
            Dictionary with job requisitions data
        """
        params = {
            '$format': 'json',
            '$top': min(top, 100),  # Max 100 per request
            '$skip': skip,
            '$select': 'jobReqId,jobReqLocale,positionTitle,country,status,externalPostingURL',
            '$expand': 'jobReqLocale'
        }
        
        # Add status filter if provided
        if status:
            params['$filter'] = f"status eq '{status}'"
        
        return self._make_request('GET', 'JobRequisition', params=params)
    
    def create_candidate(self, candidate_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a new candidate in SuccessFactors
        
        Args:
            candidate_data: Candidate information
            
        Returns:
            Created candidate data
        """
        # Transform to SuccessFactors format
        sf_candidate = {
            'firstName': candidate_data.get('name', '').split()[0] if candidate_data.get('name') else 'Unknown',
            'lastName': ' '.join(candidate_data.get('name', '').split()[1:]) if len(candidate_data.get('name', '').split()) > 1 else 'Candidate',
            'email': candidate_data.get('email', ''),
            'cellPhone': candidate_data.get('phone', ''),
            'contactEmail': candidate_data.get('email', ''),
            'zip': '00000',  # Required field
            'country': 'USA'  # Required field
        }
        
        return self._make_request('POST', 'Candidate', data=sf_candidate)
    
    def create_job_application(
        self, 
        candidate_id: str, 
        job_req_id: str
    ) -> Dict[str, Any]:
        """
        Create a job application linking candidate to job requisition
        
        Args:
            candidate_id: Candidate ID
            job_req_id: Job Requisition ID
            
        Returns:
            Created application data
        """
        application_data = {
            'candidateId': candidate_id,
            'jobReqId': job_req_id,
            'applicationDate': datetime.utcnow().strftime('%Y-%m-%dT%H:%M:%S'),
            'source': 'API',
            'status': 'New'
        }
        
        return self._make_request('POST', 'JobApplication', data=application_data)
    
    def attach_resume(
        self, 
        candidate_id: str, 
        resume_url: str
    ) -> Dict[str, Any]:
        """
        Attach resume to candidate profile
        
        Args:
            candidate_id: Candidate ID
            resume_url: URL of the resume
            
        Returns:
            Attachment data
        """
        # In real implementation, you would download and upload the resume
        # For now, we'll add it as an external reference
        attachment_data = {
            'candidateId': candidate_id,
            'attachmentType': 'Resume',
            'fileName': 'resume.pdf',
            'fileContent': resume_url,  # In real scenario, this would be base64 content
            'mimeType': 'application/pdf'
        }
        
        return self._make_request('POST', 'Attachment', data=attachment_data)
    
    def get_applications(
        self, 
        job_req_id: Optional[str] = None,
        skip: int = 0,
        top: int = 100
    ) -> Dict[str, Any]:
        """
        Get job applications
        
        Args:
            job_req_id: Filter by job requisition ID
            skip: Number of records to skip
            top: Number of records to return
            
        Returns:
            Dictionary with applications data
        """
        params = {
            '$format': 'json',
            '$top': min(top, 100),
            '$skip': skip,
            '$select': 'applicationId,candidateId,jobReqId,applicationDate,status',
            '$expand': 'candidate'
        }
        
        if job_req_id:
            params['$filter'] = f"jobReqId eq {job_req_id}"
        
        return self._make_request('GET', 'JobApplication', params=params)
    
    def get_candidate(self, candidate_id: str) -> Dict[str, Any]:
        """
        Get candidate details
        
        Args:
            candidate_id: Candidate ID
            
        Returns:
            Candidate data
        """
        endpoint = f"Candidate({candidate_id})"
        params = {'$format': 'json'}
        
        return self._make_request('GET', endpoint, params=params)
