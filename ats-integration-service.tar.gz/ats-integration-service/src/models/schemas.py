"""
Data models for API requests and responses
"""
from pydantic import BaseModel, EmailStr, Field, validator
from typing import Optional, List
from enum import Enum


class JobStatus(str, Enum):
    """Job status enumeration"""
    OPEN = "OPEN"
    CLOSED = "CLOSED"
    DRAFT = "DRAFT"


class ApplicationStatus(str, Enum):
    """Application status enumeration"""
    APPLIED = "APPLIED"
    SCREENING = "SCREENING"
    REJECTED = "REJECTED"
    HIRED = "HIRED"


class Job(BaseModel):
    """Job model for API response"""
    id: str
    title: str
    location: str
    status: JobStatus
    external_url: Optional[str] = None
    
    class Config:
        use_enum_values = True


class CandidateRequest(BaseModel):
    """Candidate creation request model"""
    name: str = Field(..., min_length=1, description="Candidate full name")
    email: EmailStr = Field(..., description="Candidate email address")
    phone: str = Field(..., min_length=10, description="Candidate phone number")
    resume_url: str = Field(..., description="URL to candidate's resume")
    job_id: str = Field(..., description="Job ID to apply for")
    
    @validator('phone')
    def validate_phone(cls, v):
        """Validate phone number format"""
        # Remove common separators
        cleaned = ''.join(filter(str.isdigit, v))
        if len(cleaned) < 10:
            raise ValueError('Phone number must be at least 10 digits')
        return v
    
    @validator('resume_url')
    def validate_resume_url(cls, v):
        """Validate resume URL"""
        if not v.startswith(('http://', 'https://')):
            raise ValueError('Resume URL must be a valid HTTP/HTTPS URL')
        return v


class CandidateResponse(BaseModel):
    """Candidate creation response model"""
    candidate_id: str
    application_id: str
    message: str
    job_id: str


class Application(BaseModel):
    """Application model for API response"""
    id: str
    candidate_name: str
    email: str
    status: ApplicationStatus
    applied_date: Optional[str] = None
    
    class Config:
        use_enum_values = True


class ErrorResponse(BaseModel):
    """Error response model"""
    error: str
    message: str
    status_code: int


class PaginatedResponse(BaseModel):
    """Base paginated response model"""
    data: List
    total: int
    skip: int
    limit: int
    has_more: bool
